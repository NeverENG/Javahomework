package lab1;
public class Print {
    public static void main(String[] args){
        System.out.println("#");
        System.out.println("##");
        System.out.println("###");
        System.out.println("####");
        System.out.println("#####");
    }
}